import 'package:flutter/material.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'pages/home_page.dart';
import 'pages/search_page.dart';
import 'pages/ai_contract_drafting.dart';
import 'pages/status_page.dart';
import 'pages/more_page.dart';
import 'pages/consultation_page.dart';
import 'pages/contract_review_page.dart';
import 'pages/welcome_page.dart';
import 'pages/login_page.dart';
import 'pages/lawyer_register_page.dart';
import 'pages/client_register_page.dart'; 
import 'pages/requests_management_page.dart';
import 'pages/otp_screen.dart';
import 'pages/lawyer_requests_page.dart';
import 'pages/lawyer_availability_page.dart';
import 'pages/lawyer_more_page.dart';
import 'pages/delete_lawyer_page.dart';
import 'pages/identity_verification_page.dart';
import 'pages/reset_password_page.dart';
import 'pages/feedback_page.dart';
import 'pages/thank_you_page.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'package:onesignal_flutter/onesignal_flutter.dart';
import 'pages/chat_screen.dart';
import 'pages/past_chat_screen.dart';
import 'pages/AIConsultationPage.dart';
import 'pages/call_manager.dart';
import 'pages/ai_page.dart';

final GlobalKey<ScaffoldMessengerState> rootScaffoldMessengerKey =
    GlobalKey<ScaffoldMessengerState>();

void main() async {

  WidgetsFlutterBinding.ensureInitialized();
   await initializeDateFormatting('ar', null);
  
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
    print('✅ Firebase initialized successfully');
  } catch (e) {
    // إذا كان مسبقاً موجود، استخدمه
    Firebase.app();
    print('✅ Using existing Firebase app');
  }
OneSignal.Debug.setLogLevel(OSLogLevel.verbose); 
OneSignal.initialize('52e7af05-5276-4ccd-9715-1cb9820f4361');
OneSignal.Notifications.requestPermission(true);
await CallManager().initAgora('0f4c50df40744feebfded2d3a3208c61');
runApp(const MyApp());

  }

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Mujeer',
      scaffoldMessengerKey: rootScaffoldMessengerKey,
      theme: ThemeData(
        snackBarTheme: const SnackBarThemeData(
      behavior: SnackBarBehavior.floating, // أهم سطر
      
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(12)),
      ),
    ),
        fontFamily: 'Tajawal', // ←   الخط موحد في كل التطبيق
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF5B4FE8)),
        textTheme: const TextTheme().apply(
          bodyColor: Colors.black, // لون النصوص العادية
          displayColor: Colors.black, // لون العناوين
        ),
      ),
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl, // ← اتجاه عربي
        child: child!,
      ),

      
      initialRoute: '/welcome',
      routes: {
        '/welcome': (context) => const WelcomePage(),
        '/home': (context) => const HomePage(),
        '/login': (context) => const LoginPage(),
        '/lawyer_register': (context) => const LawyerRegisterPage(),
        '/client_register': (context) => const ClientRegisterPage(),
        '/search': (context) => const SearchPage(),
        '/ai_contract_drafting': (context) => const AiContractDrafting(),
        '/status': (context) => const StatusPage(),
        '/more': (context) => const MorePage(),
        '/consultation': (context) => const ConsultationPage(),
        '/contractReview': (context) => const ContractReviewPage(),
        '/requestsManagement': (context) => const RequestManagementPage(),
        '/lawyer/requests':     (_) => const LawyerRequestsPage(),
        '/lawyer/availability': (_) => const LawyerAvailabilityPage(),
        '/lawyer/more':         (_) => const LawyerMorePage(),
        '/DeleteLawyerPage': (context) => const DeleteLawyerPage(),
        '/identity_verification': (context) => const IdentityVerificationPage(),
        '/reset_password': (context) => const ResetPasswordPage(username: ''),
        '/FeedbackPage': (context) => const FeedbackPage(),
        '/thankYouPage': (context) => const ThankYouPage(),
        '/ChatScreen': (context) =>  ChatScreen(),
        '/PastChatScreen': (context) =>  PastChatScreen(),
        '/AIConsultationPage': (context) =>  AIConsultationPage(),
        '/ai_page': (context) => const AIPage(),



      },
    );
  }
}
